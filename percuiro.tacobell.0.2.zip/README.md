### plugin.video.percuiro.tacobell
# Percuiro Taco Bell 


### Description 

Percurio Taco Bell is a video plugin for xbmc. You can use it to search for
video files using a combination of search providers. 
Filestube, theextopia and downtr are the default search providers.


### Features 

- ####Search & Play 

  This will search all providers in turn (sorted by customizable provider
  priority) until it finds a playable result. Playable means the file exists
  on the filehost in question and is resolvable to a link the user can 
  download.

- ####Search all enabled providers

  Although it's possible to search a specific provider it's way more 
  delicious to search all providers at once. Fiesta!

- ####Add custom search providers

  Although it still requires you to write some code you wont need a lot programming exprience
  to add your own search providers. Have a look at the format of the default providers if you
  want to give it a try. Please submit any new providers so we can make them available for everyone! 
  
  *I will add documentation for writing custom search providers in the near future.*

### Important 

This addon uses the module urlresolver to resolve search results to playable links. Without a subscribtion
of some kind to a premium (multi) file host you will be one sad donkey.

### ?Por que lo llamas percuiro Taco Bell? 

*Me gustan mucho los tacos y mi espanol es terrible.*

### Contact 

dydrmntion at gmail punkto com
