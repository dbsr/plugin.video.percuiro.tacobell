# -*- coding: utf-8 -*-
# dydrmntion@gmail.com

from xbmcswift2 import Plugin

plugin = Plugin()
